#!/usr/bin/env bash
# Build ONE double-clickable program from script_launcher.py + your shell script(s).
#
#   ./build_app.sh [-o app-name] script.sh [more-scripts.sh ...]
#
# Result: dist/<app-name>   (a single file; copy it to the other PC and double-click it)
#
# Needs, on the machine that BUILDS (not on the machine that runs it):
#   sudo apt install python3-tk python3-venv python3-pip
# Build on the same Ubuntu version (or older) than the PC that will run it.
set -euo pipefail
cd "$(dirname "$0")"

die() { echo "ERROR: $*" >&2; exit 1; }
usage() { sed -n '2,10p' "$0" | sed 's/^# \{0,1\}//'; exit 1; }

NAME=""
while getopts "o:h" opt; do
  case $opt in o) NAME=$OPTARG ;; *) usage ;; esac
done
shift $((OPTIND - 1))
(( $# >= 1 )) || usage
for s in "$@"; do [[ -f $s ]] || die "script not found: $s"; done
[[ -n $NAME ]] || NAME="$(basename "${1%.sh}")-ui"

PYTHON=${PYTHON:-python3}
"$PYTHON" -c "import tkinter" 2>/dev/null || die "Python Tk is missing.  Run:  sudo apt install python3-tk"

if [[ ! -x .build-venv/bin/pyinstaller ]]; then
  echo ">> creating build environment (first time only)"
  rm -rf .build-venv
  "$PYTHON" -m venv .build-venv || die "venv failed.  Run:  sudo apt install python3-venv python3-pip"
  .build-venv/bin/pip install -q --upgrade pip pyinstaller || die "could not install pyinstaller (needs internet access)"
fi

ADD=()
for s in "$@"; do ADD+=(--add-data "$(realpath "$s"):scripts"); done

echo ">> building dist/$NAME"
.build-venv/bin/pyinstaller --noconfirm --clean --onefile --name "$NAME" "${ADD[@]}" \
  --distpath dist --workpath build/work --specpath build \
  --exclude-module unittest --exclude-module pydoc --exclude-module doctest \
  "$PWD/script_launcher.py" >build/pyinstaller.log 2>&1 || { tail -20 build/pyinstaller.log; die "PyInstaller failed (log: build/pyinstaller.log)"; }

chmod +x "dist/$NAME"
echo ">> done: $(realpath "dist/$NAME")  ($(du -h "dist/$NAME" | cut -f1))"
echo "   Copy that single file to the other PC. Double-click it (or run ./$NAME)."
